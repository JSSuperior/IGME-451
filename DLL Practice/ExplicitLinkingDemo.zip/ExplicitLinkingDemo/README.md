# ExplicitLinkingDemo

Visual Studio 2026 solution demonstrating **explicit (run-time) linking**
against a C++ DLL. Companion to the "Creating and Using DLLs in Visual
Studio 2026" slide deck.

## Projects

- **MathLibrary** (Dynamic-Link Library) — the same library as in
  `ImplicitLinkingDemo`, exporting:
  - `int AddNumbers(int a, int b)`
  - `double CalculateCircleArea(double radius)`
  - `void FibonacciInit(unsigned long long a, unsigned long long b)` /
    `bool FibonacciNext()` / `unsigned long long FibonacciCurrent()` /
    `unsigned FibonacciIndex()`
  - `char* HelloString(char* buffer, int bufferLen)` — prepends `"Hello, "`
    to the text already in `buffer`, in place, and returns `buffer`
- **MathClientExplicit** (Console App) — does **not** include
  `MathLibrary.h` and does **not** link against `MathLibrary.lib`. Instead
  it calls `LoadLibraryA("MathLibrary.dll")` at run time, looks up each
  function by name with `GetProcAddress`, and calls each one through a
  typed function pointer.

## How explicit linking is wired up (MathClientExplicit.cpp)

```cpp
HMODULE hModule = LoadLibraryA("MathLibrary.dll");
auto AddNumbers = reinterpret_cast<AddNumbersFunc>(
    GetProcAddress(hModule, "AddNumbers"));
...
AddNumbers(10, 32);
...
FreeLibrary(hModule);
```

This only works because every exported function in `MathLibrary.h` is
declared `extern "C"`, which disables C++ name mangling — `GetProcAddress`
looks functions up by their plain, unmangled name.

Both projects write to the same output folder
(`$(SolutionDir)$(Platform)\$(Configuration)\`, e.g.
`ExplicitLinkingDemo\x64\Debug\`), so `MathLibrary.dll` sits next to
`MathClientExplicit.exe` at run time. `LoadLibraryA` searches the directory
of the calling executable first, so no copy step is needed.

## Build & run

1. Open `ExplicitLinkingDemo.sln` in Visual Studio 2026.
2. Make sure the **Desktop development with C++** workload is installed.
3. Build the solution (Debug or Release, x64) — `Ctrl+Shift+B`.
4. Set `MathClientExplicit` as the startup project if it isn't already,
   then `Ctrl+F5` (Start Without Debugging).

Expected console output (abridged):

```
AddNumbers(10, 32) = 42
CalculateCircleArea(3.0) = 28.2743
0: 1
1: 1
2: 2
...
92: 12200160415121876738
93 Fibonacci values fit in a 64-bit integer.
Hello, Explicit Linking
```

## Why HelloString takes a `char*` buffer instead of `std::string`

`std::string`'s internal layout (and heap) can differ between compiler and
CRT versions, so passing or returning one across a DLL boundary is unsafe
unless the DLL and every client are built with an identical, matching
toolset. `HelloString` sidesteps that entirely: the caller owns the buffer,
the DLL only reads and writes bytes in it, and the function reports failure
(`nullptr`) rather than silently overflowing if the buffer is too small.
