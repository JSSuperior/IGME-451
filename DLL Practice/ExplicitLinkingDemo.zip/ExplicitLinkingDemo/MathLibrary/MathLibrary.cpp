// MathLibrary.cpp : Implements the exported functions declared in
// MathLibrary.h.
#include "pch.h"
#include "MathLibrary.h"
#include <cstring>
#include <climits>
#include <utility>

// ---------------------------------------------------------------------
// Simple, stateless functions
// ---------------------------------------------------------------------

int AddNumbers(int a, int b)
{
    return a + b;
}

double CalculateCircleArea(double radius)
{
    const double PI = 3.14159265358979323846;
    return PI * radius * radius;
}

// ---------------------------------------------------------------------
// Stateful Fibonacci sequence generator
// ---------------------------------------------------------------------

// DLL-internal state. Each process that loads this DLL gets its own copy.
static unsigned long long previous_;  // Previous value, if any
static unsigned long long current_;   // Current sequence value
static unsigned index_;               // Current sequence position

void FibonacciInit(unsigned long long a, unsigned long long b)
{
    index_ = 0;
    current_ = a;
    previous_ = b;
}

bool FibonacciNext()
{
    if ((ULLONG_MAX - previous_ < current_) ||
        (UINT_MAX == index_))
    {
        return false;
    }

    if (index_ > 0)
    {
        previous_ += current_;
    }
    std::swap(current_, previous_);
    ++index_;
    return true;
}

unsigned long long FibonacciCurrent()
{
    return current_;
}

unsigned FibonacciIndex()
{
    return index_;
}

// ---------------------------------------------------------------------
// String example
// ---------------------------------------------------------------------

char* HelloString(char* buffer, int bufferLen)
{
    static const char prefix[] = "Hello, ";
    const size_t prefixLen = sizeof(prefix) - 1; // 7 characters, excludes '\0'

    if (buffer == nullptr || bufferLen <= 0)
    {
        return nullptr;
    }

    const size_t textLen = strnlen(buffer, static_cast<size_t>(bufferLen));
    const size_t neededLen = prefixLen + textLen + 1; // +1 for the null terminator

    if (neededLen > static_cast<size_t>(bufferLen))
    {
        return nullptr; // buffer is too small to hold "Hello, " + the text
    }

    // Shift the existing text right to make room for the prefix, then copy
    // the prefix into place. memmove (not memcpy) is required because the
    // source and destination ranges overlap.
    memmove(buffer + prefixLen, buffer, textLen + 1);
    memcpy(buffer, prefix, prefixLen);

    return buffer;
}
