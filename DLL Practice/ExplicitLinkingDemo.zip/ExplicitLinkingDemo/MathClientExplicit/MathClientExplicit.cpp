// MathClientExplicit.cpp : Demonstrates EXPLICIT (run-time) linking against
// MathLibrary.dll.
//
// Unlike the implicit-linking demo, this project does NOT include
// MathLibrary.h and does NOT link against MathLibrary.lib. Instead it loads
// the DLL itself at run time with LoadLibraryA(), looks up each exported
// function by name with GetProcAddress(), and calls the functions through
// typed function pointers. This is the pattern you'd use for optional
// dependencies or a plugin architecture, where the DLL to load might not
// even be known until the program is running.
#include <iostream>
#include <windows.h>

// Function-pointer types matching MathLibrary's exported signatures
// (see MathLibrary.h in the DLL project for the authoritative declarations).
typedef int (*AddNumbersFunc)(int, int);
typedef double (*CalculateCircleAreaFunc)(double);
typedef void (*FibonacciInitFunc)(unsigned long long, unsigned long long);
typedef bool (*FibonacciNextFunc)();
typedef unsigned long long (*FibonacciCurrentFunc)();
typedef unsigned (*FibonacciIndexFunc)();
typedef char* (*HelloStringFunc)(char*, int);

// Looks up one exported function by name and reports an error if it's missing.
template <typename FuncPtr>
static FuncPtr LoadFunction(HMODULE hModule, const char* name)
{
    FuncPtr fn = reinterpret_cast<FuncPtr>(GetProcAddress(hModule, name));
    if (fn == nullptr)
    {
        std::cerr << "Failed to find " << name << std::endl;
    }
    return fn;
}

int main()
{
    HMODULE hModule = LoadLibraryA("MathLibrary.dll");
    if (hModule == nullptr)
    {
        std::cerr << "Failed to load MathLibrary.dll" << std::endl;
        return 1;
    }

    auto AddNumbers          = LoadFunction<AddNumbersFunc>(hModule, "AddNumbers");
    auto CalculateCircleArea = LoadFunction<CalculateCircleAreaFunc>(hModule, "CalculateCircleArea");
    auto FibonacciInit       = LoadFunction<FibonacciInitFunc>(hModule, "FibonacciInit");
    auto FibonacciNext       = LoadFunction<FibonacciNextFunc>(hModule, "FibonacciNext");
    auto FibonacciCurrent    = LoadFunction<FibonacciCurrentFunc>(hModule, "FibonacciCurrent");
    auto FibonacciIndex      = LoadFunction<FibonacciIndexFunc>(hModule, "FibonacciIndex");
    auto HelloString         = LoadFunction<HelloStringFunc>(hModule, "HelloString");

    if (!AddNumbers || !CalculateCircleArea || !FibonacciInit ||
        !FibonacciNext || !FibonacciCurrent || !FibonacciIndex || !HelloString)
    {
        FreeLibrary(hModule);
        return 1;
    }

    // ---- AddNumbers / CalculateCircleArea ----
    std::cout << "AddNumbers(10, 32) = "
              << AddNumbers(10, 32) << std::endl;
    std::cout << "CalculateCircleArea(3.0) = "
              << CalculateCircleArea(3.0) << std::endl;

    // ---- Fibonacci sequence ----
    FibonacciInit(1, 1);
    do {
        std::cout << FibonacciIndex() << ": "
                  << FibonacciCurrent() << std::endl;
    } while (FibonacciNext());

    std::cout << FibonacciIndex() + 1
              << " Fibonacci values fit in a 64-bit integer."
              << std::endl;

    // ---- HelloString ----
    char greeting[64];
    strcpy_s(greeting, "Explicit Linking");     // greeting now holds "Explicit Linking"
    if (HelloString(greeting, sizeof(greeting)) != nullptr)
    {
        std::cout << greeting << std::endl;     // prints "Hello, Explicit Linking"
    }
    else
    {
        std::cerr << "HelloString: buffer too small" << std::endl;
    }

    FreeLibrary(hModule);
    return 0;
}
