// MathClient.cpp : Demonstrates IMPLICIT (load-time) linking against
// MathLibrary.dll.
//
// This project links against MathLibrary.lib (the import library) at build
// time -- see the project's C/C++ > General > Additional Include
// Directories and Linker > Input > Additional Dependencies settings.
// Windows loads MathLibrary.dll automatically when MathClient.exe starts,
// and every exported function can be called directly, as if it were an
// ordinary function in this project.
#include <iostream>
#include "MathLibrary.h"

int main()
{
	// ---- AddNumbers / CalculateCircleArea ----
	std::cout << "AddNumbers(3, 4) = "
		<< AddNumbers(3, 4) << std::endl;
	std::cout << "CalculateCircleArea(2.0) = "
		<< CalculateCircleArea(2.0) << std::endl;

	// ---- Fibonacci sequence ----
	FibonacciInit(1, 1);
	do {
		std::cout << FibonacciIndex() << ": "
			<< FibonacciCurrent() << std::endl;
	} while (FibonacciNext());

	std::cout << FibonacciIndex() + 1
		<< " Fibonacci values fit in a 64-bit integer."
		<< std::endl;

	// ---- HelloString ----
	char greeting[64];
	strcpy_s(greeting, "World");             // greeting now holds "World"
	if (HelloString(greeting, sizeof(greeting)) != nullptr)
	{
		std::cout << greeting << std::endl;  // prints "Hello, World"
	}
	else
	{
		std::cerr << "HelloString: buffer too small" << std::endl;
	}
}
