# ImplicitLinkingDemo

Visual Studio 2026 solution demonstrating **implicit (load-time) linking**
against a C++ DLL. Companion to the "Creating and Using DLLs in Visual
Studio 2026" slide deck.

## Projects

- **MathLibrary** (Dynamic-Link Library) — exports:
  - `int AddNumbers(int a, int b)`
  - `double CalculateCircleArea(double radius)`
  - `void FibonacciInit(unsigned long long a, unsigned long long b)` /
    `bool FibonacciNext()` / `unsigned long long FibonacciCurrent()` /
    `unsigned FibonacciIndex()` — a small stateful Fibonacci generator
  - `char* HelloString(char* buffer, int bufferLen)` — prepends `"Hello, "`
    to the text already in `buffer`, in place, and returns `buffer`
- **MathClient** (Console App) — links against `MathLibrary.lib` at build
  time and calls every exported function directly, the same way it would
  call a function defined in its own project.

## How implicit linking is wired up (MathClient project properties)

| Setting | Value |
|---|---|
| C/C++ › General › Additional Include Directories | `..\MathLibrary` |
| Linker › Input › Additional Dependencies | `MathLibrary.lib` |
| Linker › General › Additional Library Directories | `$(OutDir)` |
| General › Output Directory (all projects) | `$(SolutionDir)$(Platform)\$(Configuration)\` |

Because every project in the solution writes to the same output folder
(e.g. `ImplicitLinkingDemo\x64\Debug\`), the linker finds `MathLibrary.lib`
there, and `MathLibrary.dll` already sits next to `MathClient.exe` at run
time. No post-build copy step is needed.

A solution-level **Project Dependency** (MathClient depends on MathLibrary)
and a build-order-only `ProjectReference` both guarantee MathLibrary
finishes building (so `MathLibrary.lib` exists) before MathClient links.

## Build & run

1. Open `ImplicitLinkingDemo.sln` in Visual Studio 2026.
2. Make sure the **Desktop development with C++** workload is installed.
3. Build the solution (Debug or Release, x64) — `Ctrl+Shift+B`.
4. Set `MathClient` as the startup project if it isn't already, then
   `Ctrl+F5` (Start Without Debugging).

Expected console output (abridged):

```
AddNumbers(3, 4) = 7
CalculateCircleArea(2.0) = 12.5664
0: 1
1: 1
2: 2
3: 3
4: 5
5: 8
...
92: 12200160415121876738
93 Fibonacci values fit in a 64-bit integer.
Hello, World
```

## Why HelloString takes a `char*` buffer instead of `std::string`

`std::string`'s internal layout (and heap) can differ between compiler and
CRT versions, so passing or returning one across a DLL boundary is unsafe
unless the DLL and every client are built with an identical, matching
toolset. `HelloString` sidesteps that entirely: the caller owns the buffer,
the DLL only reads and writes bytes in it, and the function reports failure
(`nullptr`) rather than silently overflowing if the buffer is too small.
