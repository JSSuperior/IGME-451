// MathLibrary.h - Public interface for MathLibrary.dll.
//
// This single header is shared by the DLL build (which defines
// MATHLIBRARY_EXPORTS, via the project's Preprocessor Definitions) and by
// every client build (which does not), so MATHLIBRARY_API expands to
// __declspec(dllexport) on one side and __declspec(dllimport) on the other.
//
// Every exported declaration uses extern "C" so the symbol is NOT C++ name
// mangled. That keeps the exported names stable across compiler versions
// and lets MathClientExplicit.cpp look functions up by plain name with
// GetProcAddress().
#pragma once

#ifdef MATHLIBRARY_EXPORTS
#define MATHLIBRARY_API __declspec(dllexport)
#else
#define MATHLIBRARY_API __declspec(dllimport)
#endif

// ---------------------------------------------------------------------
// Simple, stateless functions (parameters in, return value out)
// ---------------------------------------------------------------------

// Adds two integers and returns the sum.
extern "C" MATHLIBRARY_API int AddNumbers(int a, int b);

// Returns the area of a circle with the given radius.
extern "C" MATHLIBRARY_API double CalculateCircleArea(double radius);

// ---------------------------------------------------------------------
// Stateful Fibonacci sequence generator
// ---------------------------------------------------------------------

// Initialize a Fibonacci relation sequence such that F(0) = a, F(1) = b.
// This function must be called before FibonacciNext/Current/Index.
extern "C" MATHLIBRARY_API void FibonacciInit(
    unsigned long long a, unsigned long long b);

// Produce the next value in the sequence.
// Returns true on success and advances the sequence; false on overflow,
// in which case the current value and index are left unchanged.
extern "C" MATHLIBRARY_API bool FibonacciNext();

// Get the current value in the sequence.
extern "C" MATHLIBRARY_API unsigned long long FibonacciCurrent();

// Get the position (index) of the current value in the sequence.
extern "C" MATHLIBRARY_API unsigned FibonacciIndex();

// ---------------------------------------------------------------------
// String example: modifies a caller-supplied buffer and returns it
// ---------------------------------------------------------------------

// Prepends "Hello, " to the text in the caller-supplied buffer, IN PLACE,
// and returns the same pointer.
//
//   buffer    - A null-terminated, writable character buffer. On input it
//               holds the text to greet (e.g. "World"); on output it holds
//               the greeting (e.g. "Hello, World").
//   bufferLen - The total size of buffer, in bytes, including room for the
//               null terminator.
//
// Returns buffer on success, or nullptr if buffer is null or too small to
// hold the result.
//
// Note: the exported signature intentionally uses a plain char* rather than
// std::string. A std::string's internal layout (and even its heap) can
// differ between compiler/CRT versions, so passing or returning one across
// a DLL boundary is unsafe unless the DLL and every client are built with
// an identical, matching toolset -- see "Common Pitfalls" in the companion
// slide deck, "Creating and Using DLLs in Visual Studio 2026".
extern "C" MATHLIBRARY_API char* HelloString(char* buffer, int bufferLen);
