.DATA
valA QWORD 10
valB QWORD 20

.CODE
TestAssembly PROC
MOV RAX, valA
ADD RAX, valB
RET
TestAssembly ENDP

AddTwoNumbers PROC
MOV RAX, RCX
ADD RAX, RDX
RET
AddTwoNumbers ENDP

SubTwoNumbers PROC
MOV RAX, RCX
SUB RAX, RDX
RET
SubTwoNumbers ENDP

MulTwoNumbers PROC
MOV RAX, RCX
MUL RDX
RET
MulTwoNumbers ENDP

END