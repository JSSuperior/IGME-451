// AssemblyTest.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

extern "C" uint64_t TestAssembly();
extern "C" uint64_t AddTwoNumbers(uint64_t, uint64_t);
extern "C" uint64_t SubTwoNumbers(uint64_t, uint64_t);
extern "C" uint64_t MulTwoNumbers(uint64_t, uint64_t);

int main()
{
    cout << "Value returned: " << TestAssembly() << endl;
    cout << "Value returned: " << AddTwoNumbers(50,70) << endl;
    cout << "Value returned: " << SubTwoNumbers(70, 50) << endl;
    cout << "Value returned: " << MulTwoNumbers(50, 70) << endl;
    //std::cout << "Hello World!\n";
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

